import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { FileCode, FileText, Download } from "lucide-react";

interface ExportModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function ExportModal({ open, onOpenChange }: ExportModalProps) {
  const [includeNotes, setIncludeNotes] = useState(true);
  const { toast } = useToast();

  const handleExportJSON = async () => {
    try {
      const response = await fetch('/api/export', {
        method: 'GET',
        credentials: 'include',
      });
      
      if (!response.ok) {
        throw new Error('Error al exportar datos');
      }
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = `territory-backup-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Exportación exitosa",
        description: "Los datos se han exportado en formato JSON.",
      });
      
      onOpenChange(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo exportar los datos.",
        variant: "destructive",
      });
    }
  };

  const handleExportCSV = async () => {
    try {
      const response = await fetch('/api/territory-records', {
        method: 'GET',
        credentials: 'include',
      });
      
      if (!response.ok) {
        throw new Error('Error al obtener datos');
      }
      
      const records = await response.json();
      
      // Convert to CSV
      const headers = ['Territorio', 'Encargado', 'Fecha Inicio', 'Fecha Final', 'Observaciones'];
      const csvContent = [
        headers.join(','),
        ...records.map((record: any) => [
          record.territoryNumber,
          `"${record.personInCharge}"`,
          record.startDate,
          record.endDate,
          includeNotes ? `"${record.notes || ''}"` : '""'
        ].join(','))
      ].join('\n');
      
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = `territory-records-${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Exportación exitosa",
        description: "Los datos se han exportado en formato CSV.",
      });
      
      onOpenChange(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo exportar los datos.",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-lg font-semibold text-slate-800">
            Exportar Datos
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <p className="text-sm text-slate-600">
            Seleccione el formato de exportación para sus datos:
          </p>
          
          <div className="space-y-3">
            <Button
              variant="outline"
              className="w-full justify-start h-auto p-3"
              onClick={handleExportJSON}
            >
              <FileCode className="text-blue-600 mr-3 h-5 w-5" />
              <div className="text-left">
                <div className="font-medium text-slate-800">Archivo JSON</div>
                <div className="text-sm text-slate-600">Para respaldo completo de datos</div>
              </div>
            </Button>
            
            <Button
              variant="outline"
              className="w-full justify-start h-auto p-3"
              onClick={handleExportCSV}
            >
              <FileText className="text-green-600 mr-3 h-5 w-5" />
              <div className="text-left">
                <div className="font-medium text-slate-800">Archivo CSV</div>
                <div className="text-sm text-slate-600">Para importar en Excel</div>
              </div>
            </Button>
          </div>

          <div className="pt-4 border-t border-slate-200">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="includeNotes"
                checked={includeNotes}
                onCheckedChange={(checked) => setIncludeNotes(!!checked)}
              />
              <label
                htmlFor="includeNotes"
                className="text-sm text-slate-600 cursor-pointer"
              >
                Incluir todas las observaciones
              </label>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
