import { useState, useRef } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { CloudUpload, AlertTriangle } from "lucide-react";

interface ImportModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function ImportModal({ open, onOpenChange }: ImportModalProps) {
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const importDataMutation = useMutation({
    mutationFn: async (data: any) => {
      await apiRequest("POST", "/api/import", data);
    },
    onSuccess: () => {
      toast({
        title: "Importación exitosa",
        description: "Los datos se han importado correctamente.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/territory-records"] });
      onOpenChange(false);
      setSelectedFile(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo importar los datos.",
        variant: "destructive",
      });
    },
  });

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.type === "application/json" || file.name.endsWith('.json')) {
        setSelectedFile(file);
      } else {
        toast({
          title: "Archivo no válido",
          description: "Por favor seleccione un archivo JSON.",
          variant: "destructive",
        });
      }
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.type === "application/json" || file.name.endsWith('.json')) {
        setSelectedFile(file);
      } else {
        toast({
          title: "Archivo no válido",
          description: "Por favor seleccione un archivo JSON.",
          variant: "destructive",
        });
      }
    }
  };

  const handleImport = async () => {
    if (!selectedFile) return;

    try {
      const text = await selectedFile.text();
      const data = JSON.parse(text);
      
      if (!data.territoryRecords || !Array.isArray(data.territoryRecords)) {
        throw new Error("Formato de archivo no válido");
      }
      
      importDataMutation.mutate(data);
    } catch (error) {
      toast({
        title: "Error",
        description: "El archivo no tiene un formato válido.",
        variant: "destructive",
      });
    }
  };

  const openFileDialog = () => {
    fileInputRef.current?.click();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-lg font-semibold text-slate-800">
            Restaurar Datos
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div
            className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
              dragActive 
                ? 'border-blue-400 bg-blue-50' 
                : 'border-slate-300 hover:border-slate-400'
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <CloudUpload className="mx-auto h-12 w-12 text-slate-400 mb-4" />
            
            {selectedFile ? (
              <div>
                <p className="text-sm font-medium text-slate-800 mb-2">
                  Archivo seleccionado:
                </p>
                <p className="text-sm text-slate-600 mb-4">
                  {selectedFile.name}
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedFile(null)}
                >
                  Cambiar archivo
                </Button>
              </div>
            ) : (
              <div>
                <p className="text-sm text-slate-600 mb-2">
                  Arrastre su archivo de respaldo aquí o
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={openFileDialog}
                >
                  seleccione un archivo
                </Button>
              </div>
            )}
            
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              onChange={handleFileSelect}
              className="hidden"
            />
          </div>
          
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <strong>Advertencia:</strong> Esta acción reemplazará todos los datos actuales. 
              Se recomienda hacer una copia de seguridad primero.
            </AlertDescription>
          </Alert>

          <div className="flex justify-end space-x-3">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancelar
            </Button>
            <Button
              onClick={handleImport}
              disabled={!selectedFile || importDataMutation.isPending}
              className="bg-amber-600 hover:bg-amber-700"
            >
              {importDataMutation.isPending ? "Restaurando..." : "Restaurar Datos"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
