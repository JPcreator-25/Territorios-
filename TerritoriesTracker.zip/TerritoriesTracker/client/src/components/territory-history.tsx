import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { type TerritoryRecord } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Edit, Trash2, Search } from "lucide-react";

export default function TerritoryHistory() {
  const [searchTerritory, setSearchTerritory] = useState("all");
  const [searchPerson, setSearchPerson] = useState("");
  const [deleteRecordId, setDeleteRecordId] = useState<number | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch all records
  const { data: allRecords = [], isLoading } = useQuery<TerritoryRecord[]>({
    queryKey: ["/api/territory-records"],
  });

  const deleteRecordMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/territory-records/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Registro eliminado",
        description: "El registro se ha eliminado exitosamente.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/territory-records"] });
      setDeleteRecordId(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo eliminar el registro.",
        variant: "destructive",
      });
    },
  });

  // Filter records based on search criteria
  const filteredRecords = allRecords.filter((record) => {
    const matchesTerritory = !searchTerritory || searchTerritory === "all" || record.territoryNumber.toString() === searchTerritory;
    const matchesPerson = !searchPerson || record.personInCharge.toLowerCase().includes(searchPerson.toLowerCase());
    return matchesTerritory && matchesPerson;
  });

  const handleDelete = (id: number) => {
    setDeleteRecordId(id);
  };

  const confirmDelete = () => {
    if (deleteRecordId) {
      deleteRecordMutation.mutate(deleteRecordId);
    }
  };

  const calculateDuration = (startDate: string, endDate: string) => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    const diffTime = Math.abs(end.getTime() - start.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return `${diffDays} día${diffDays !== 1 ? 's' : ''}`;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="text-slate-500">Cargando registros...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Search and Filter */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row sm:items-end sm:space-x-4 space-y-4 sm:space-y-0">
            <div className="flex-1">
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Buscar por Territorio
              </label>
              <Select value={searchTerritory} onValueChange={setSearchTerritory}>
                <SelectTrigger>
                  <SelectValue placeholder="Todos los territorios" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los territorios</SelectItem>
                  {Array.from({ length: 34 }, (_, i) => i + 1).map((num) => (
                    <SelectItem key={num} value={num.toString()}>
                      Territorio {num}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex-1">
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Buscar por Encargado
              </label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
                <Input
                  placeholder="Nombre del encargado..."
                  value={searchPerson}
                  onChange={(e) => setSearchPerson(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Territory History Table */}
      <Card>
        <CardHeader className="bg-slate-50 border-b border-slate-200">
          <CardTitle className="text-lg font-semibold text-slate-800">
            Historial de Territorios
          </CardTitle>
          <CardDescription className="text-sm text-slate-600">
            Registro completo de trabajos realizados
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          {filteredRecords.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-slate-500">
                {allRecords.length === 0 
                  ? "No hay registros disponibles" 
                  : "No se encontraron registros que coincidan con los criterios de búsqueda"
                }
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-slate-50">
                    <TableHead className="font-medium text-slate-500 uppercase text-xs tracking-wider">
                      Territorio
                    </TableHead>
                    <TableHead className="font-medium text-slate-500 uppercase text-xs tracking-wider">
                      Encargado
                    </TableHead>
                    <TableHead className="font-medium text-slate-500 uppercase text-xs tracking-wider">
                      Fecha Inicio
                    </TableHead>
                    <TableHead className="font-medium text-slate-500 uppercase text-xs tracking-wider">
                      Fecha Final
                    </TableHead>
                    <TableHead className="font-medium text-slate-500 uppercase text-xs tracking-wider">
                      Duración
                    </TableHead>
                    <TableHead className="font-medium text-slate-500 uppercase text-xs tracking-wider">
                      Observaciones
                    </TableHead>
                    <TableHead className="font-medium text-slate-500 uppercase text-xs tracking-wider">
                      Acciones
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRecords.map((record) => (
                    <TableRow key={record.id} className="hover:bg-slate-50">
                      <TableCell>
                        <div className="flex items-center">
                          <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center text-sm font-semibold">
                            {record.territoryNumber}
                          </div>
                          <span className="ml-3 text-sm font-medium text-slate-800">
                            Territorio {record.territoryNumber}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="text-sm text-slate-800">
                        {record.personInCharge}
                      </TableCell>
                      <TableCell className="text-sm text-slate-600">
                        {new Date(record.startDate).toLocaleDateString('es-ES')}
                      </TableCell>
                      <TableCell className="text-sm text-slate-600">
                        {new Date(record.endDate).toLocaleDateString('es-ES')}
                      </TableCell>
                      <TableCell className="text-sm text-slate-600">
                        {calculateDuration(record.startDate, record.endDate)}
                      </TableCell>
                      <TableCell className="text-sm text-slate-600 max-w-xs">
                        <div className="truncate" title={record.notes || ""}>
                          {record.notes || "Sin observaciones"}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-blue-600 hover:text-blue-800 p-1"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDelete(record.id)}
                            className="text-red-600 hover:text-red-800 p-1"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>

        {/* Pagination info */}
        {filteredRecords.length > 0 && (
          <div className="px-6 py-4 border-t border-slate-200 bg-slate-50">
            <div className="text-sm text-slate-600">
              Mostrando {filteredRecords.length} de {allRecords.length} registros
            </div>
          </div>
        )}
      </Card>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteRecordId !== null} onOpenChange={() => setDeleteRecordId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Confirmar eliminación?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer. El registro será eliminado permanentemente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
