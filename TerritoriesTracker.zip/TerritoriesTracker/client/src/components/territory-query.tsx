import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { type TerritoryRecord } from "@shared/schema";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Calendar, User, FileText, Clock } from "lucide-react";

export default function TerritoryQuery() {
  const [selectedTerritory, setSelectedTerritory] = useState<string>("");

  // Fetch records for the selected territory
  const { data: territoryRecords = [], isLoading } = useQuery<TerritoryRecord[]>({
    queryKey: ["/api/territory-records", "territory", selectedTerritory],
    queryFn: async () => {
      if (!selectedTerritory) return [];
      const response = await fetch(`/api/territory-records/territory/${selectedTerritory}`);
      if (!response.ok) throw new Error('Error al cargar los registros');
      return response.json();
    },
    enabled: !!selectedTerritory,
  });

  const calculateDuration = (startDate: string, endDate: string) => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    const diffTime = Math.abs(end.getTime() - start.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return `${diffDays} día${diffDays !== 1 ? 's' : ''}`;
  };

  return (
    <div className="space-y-6">
      {/* Territory Selection */}
      <Card>
        <CardHeader className="bg-slate-50 border-b border-slate-200">
          <CardTitle className="text-lg font-semibold text-slate-800">
            Consulta de Territorio
          </CardTitle>
          <CardDescription className="text-sm text-slate-600">
            Seleccione un territorio para ver su historial completo
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="max-w-md">
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Territorio a Consultar
            </label>
            <Select value={selectedTerritory} onValueChange={setSelectedTerritory}>
              <SelectTrigger>
                <SelectValue placeholder="Seleccione un territorio..." />
              </SelectTrigger>
              <SelectContent>
                {Array.from({ length: 34 }, (_, i) => i + 1).map((num) => (
                  <SelectItem key={num} value={num.toString()}>
                    Territorio {num}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Territory History Results */}
      {selectedTerritory && (
        <Card>
          <CardHeader className="bg-slate-50 border-b border-slate-200">
            <CardTitle className="text-lg font-semibold text-slate-800 flex items-center">
              <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center text-sm font-semibold mr-3">
                {selectedTerritory}
              </div>
              Historial del Territorio {selectedTerritory}
            </CardTitle>
            <CardDescription className="text-sm text-slate-600">
              {territoryRecords.length > 0 
                ? `${territoryRecords.length} registro${territoryRecords.length !== 1 ? 's' : ''} encontrado${territoryRecords.length !== 1 ? 's' : ''}`
                : 'No hay registros para este territorio'
              }
            </CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="text-slate-500">Cargando historial...</div>
              </div>
            ) : territoryRecords.length === 0 ? (
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <FileText className="h-8 w-8 text-slate-400" />
                </div>
                <p className="text-slate-500 mb-2">Sin registros disponibles</p>
                <p className="text-sm text-slate-400">
                  Este territorio aún no ha sido trabajado o no tiene registros guardados.
                </p>
              </div>
            ) : (
              <div className="space-y-6">
                {territoryRecords.map((record, index) => (
                  <div key={record.id} className="relative">
                    {/* Timeline connector */}
                    {index !== territoryRecords.length - 1 && (
                      <div className="absolute left-6 top-16 w-0.5 h-full bg-slate-200 -z-10"></div>
                    )}
                    
                    <div className="flex items-start space-x-4">
                      {/* Timeline dot */}
                      <div className="w-12 h-12 bg-white border-4 border-blue-200 rounded-full flex items-center justify-center flex-shrink-0 relative z-10">
                        <div className="w-4 h-4 bg-blue-500 rounded-full"></div>
                      </div>
                      
                      {/* Record content */}
                      <div className="flex-1 min-w-0">
                        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-sm">
                          {/* Header with person and dates */}
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center space-x-3">
                              <div className="flex items-center text-slate-700">
                                <User className="h-4 w-4 mr-2 text-slate-500" />
                                <span className="font-medium">{record.personInCharge}</span>
                              </div>
                              <Badge variant="secondary" className="text-xs">
                                {calculateDuration(record.startDate, record.endDate)}
                              </Badge>
                            </div>
                            <div className="text-sm text-slate-500">
                              #{record.id}
                            </div>
                          </div>
                          
                          {/* Dates */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                            <div className="flex items-center text-sm text-slate-600">
                              <Calendar className="h-4 w-4 mr-2 text-green-500" />
                              <div>
                                <div className="font-medium">Fecha de Inicio</div>
                                <div>{new Date(record.startDate).toLocaleDateString('es-ES', {
                                  weekday: 'long',
                                  year: 'numeric',
                                  month: 'long',
                                  day: 'numeric'
                                })}</div>
                              </div>
                            </div>
                            <div className="flex items-center text-sm text-slate-600">
                              <Calendar className="h-4 w-4 mr-2 text-red-500" />
                              <div>
                                <div className="font-medium">Fecha Final</div>
                                <div>{new Date(record.endDate).toLocaleDateString('es-ES', {
                                  weekday: 'long',
                                  year: 'numeric',
                                  month: 'long',
                                  day: 'numeric'
                                })}</div>
                              </div>
                            </div>
                          </div>
                          
                          {/* Notes */}
                          {record.notes && (
                            <>
                              <Separator className="my-4" />
                              <div>
                                <div className="flex items-center text-sm font-medium text-slate-700 mb-2">
                                  <FileText className="h-4 w-4 mr-2 text-slate-500" />
                                  Observaciones
                                </div>
                                <div className="text-sm text-slate-600 bg-slate-50 rounded-md p-3">
                                  {record.notes}
                                </div>
                              </div>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}