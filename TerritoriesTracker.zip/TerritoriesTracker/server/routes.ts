import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTerritoryRecordSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all territory records
  app.get("/api/territory-records", async (req, res) => {
    try {
      const records = await storage.getTerritoryRecords();
      res.json(records);
    } catch (error) {
      res.status(500).json({ message: "Error fetching territory records" });
    }
  });

  // Get territory record by ID
  app.get("/api/territory-records/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const record = await storage.getTerritoryRecord(id);
      
      if (!record) {
        return res.status(404).json({ message: "Territory record not found" });
      }
      
      res.json(record);
    } catch (error) {
      res.status(500).json({ message: "Error fetching territory record" });
    }
  });

  // Create new territory record
  app.post("/api/territory-records", async (req, res) => {
    try {
      const validatedData = insertTerritoryRecordSchema.parse(req.body);
      const record = await storage.createTerritoryRecord(validatedData);
      res.status(201).json(record);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating territory record" });
    }
  });

  // Update territory record
  app.put("/api/territory-records/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertTerritoryRecordSchema.partial().parse(req.body);
      const record = await storage.updateTerritoryRecord(id, validatedData);
      
      if (!record) {
        return res.status(404).json({ message: "Territory record not found" });
      }
      
      res.json(record);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating territory record" });
    }
  });

  // Delete territory record
  app.delete("/api/territory-records/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteTerritoryRecord(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Territory record not found" });
      }
      
      res.json({ message: "Territory record deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Error deleting territory record" });
    }
  });

  // Get territory records by territory number
  app.get("/api/territory-records/territory/:number", async (req, res) => {
    try {
      const territoryNumber = parseInt(req.params.number);
      const records = await storage.getTerritoryRecordsByNumber(territoryNumber);
      res.json(records);
    } catch (error) {
      res.status(500).json({ message: "Error fetching territory records" });
    }
  });

  // Search territory records by person
  app.get("/api/territory-records/search", async (req, res) => {
    try {
      const personName = req.query.person as string;
      if (!personName) {
        return res.status(400).json({ message: "Person name is required" });
      }
      
      const records = await storage.searchTerritoryRecordsByPerson(personName);
      res.json(records);
    } catch (error) {
      res.status(500).json({ message: "Error searching territory records" });
    }
  });

  // Export data
  app.get("/api/export", async (req, res) => {
    try {
      const data = (storage as any).exportData();
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', 'attachment; filename=territory-backup.json');
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: "Error exporting data" });
    }
  });

  // Import data
  app.post("/api/import", async (req, res) => {
    try {
      const data = req.body;
      if (!data.territoryRecords || !Array.isArray(data.territoryRecords)) {
        return res.status(400).json({ message: "Invalid backup file format" });
      }
      
      (storage as any).importData(data);
      res.json({ message: "Data imported successfully" });
    } catch (error) {
      res.status(500).json({ message: "Error importing data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
