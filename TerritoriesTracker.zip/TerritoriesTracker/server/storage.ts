import { users, type User, type InsertUser, territoryRecords, type TerritoryRecord, type InsertTerritoryRecord } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Territory records methods
  getTerritoryRecords(): Promise<TerritoryRecord[]>;
  getTerritoryRecord(id: number): Promise<TerritoryRecord | undefined>;
  createTerritoryRecord(record: InsertTerritoryRecord): Promise<TerritoryRecord>;
  updateTerritoryRecord(id: number, record: Partial<InsertTerritoryRecord>): Promise<TerritoryRecord | undefined>;
  deleteTerritoryRecord(id: number): Promise<boolean>;
  getTerritoryRecordsByNumber(territoryNumber: number): Promise<TerritoryRecord[]>;
  searchTerritoryRecordsByPerson(personName: string): Promise<TerritoryRecord[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getTerritoryRecords(): Promise<TerritoryRecord[]> {
    const records = await db.select().from(territoryRecords).orderBy(territoryRecords.id);
    return records.sort((a, b) => b.id - a.id);
  }

  async getTerritoryRecord(id: number): Promise<TerritoryRecord | undefined> {
    const [record] = await db.select().from(territoryRecords).where(eq(territoryRecords.id, id));
    return record || undefined;
  }

  async createTerritoryRecord(insertRecord: InsertTerritoryRecord): Promise<TerritoryRecord> {
    const [record] = await db
      .insert(territoryRecords)
      .values({
        ...insertRecord,
        notes: insertRecord.notes || null
      })
      .returning();
    return record;
  }

  async updateTerritoryRecord(id: number, updateRecord: Partial<InsertTerritoryRecord>): Promise<TerritoryRecord | undefined> {
    const [record] = await db
      .update(territoryRecords)
      .set({
        ...updateRecord,
        notes: updateRecord.notes || null
      })
      .where(eq(territoryRecords.id, id))
      .returning();
    return record || undefined;
  }

  async deleteTerritoryRecord(id: number): Promise<boolean> {
    const result = await db.delete(territoryRecords).where(eq(territoryRecords.id, id));
    return (result.rowCount || 0) > 0;
  }

  async getTerritoryRecordsByNumber(territoryNumber: number): Promise<TerritoryRecord[]> {
    const records = await db
      .select()
      .from(territoryRecords)
      .where(eq(territoryRecords.territoryNumber, territoryNumber))
      .orderBy(territoryRecords.startDate);
    return records.sort((a, b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime());
  }

  async searchTerritoryRecordsByPerson(personName: string): Promise<TerritoryRecord[]> {
    const records = await db.select().from(territoryRecords);
    const searchTerm = personName.toLowerCase();
    return records
      .filter(record => record.personInCharge.toLowerCase().includes(searchTerm))
      .sort((a, b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime());
  }

  exportData(): { territoryRecords: TerritoryRecord[] } {
    throw new Error("Export not implemented for database storage");
  }

  importData(data: { territoryRecords: TerritoryRecord[] }): void {
    throw new Error("Import not implemented for database storage");
  }
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private territoryRecords: Map<number, TerritoryRecord>;
  private currentUserId: number;
  private currentRecordId: number;

  constructor() {
    this.users = new Map();
    this.territoryRecords = new Map();
    this.currentUserId = 1;
    this.currentRecordId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getTerritoryRecords(): Promise<TerritoryRecord[]> {
    return Array.from(this.territoryRecords.values()).sort((a, b) => b.id - a.id);
  }

  async getTerritoryRecord(id: number): Promise<TerritoryRecord | undefined> {
    return this.territoryRecords.get(id);
  }

  async createTerritoryRecord(insertRecord: InsertTerritoryRecord): Promise<TerritoryRecord> {
    const id = this.currentRecordId++;
    const record: TerritoryRecord = { 
      ...insertRecord, 
      id,
      notes: insertRecord.notes || null
    };
    this.territoryRecords.set(id, record);
    return record;
  }

  async updateTerritoryRecord(id: number, updateRecord: Partial<InsertTerritoryRecord>): Promise<TerritoryRecord | undefined> {
    const existingRecord = this.territoryRecords.get(id);
    if (!existingRecord) {
      return undefined;
    }
    
    const updatedRecord: TerritoryRecord = { ...existingRecord, ...updateRecord };
    this.territoryRecords.set(id, updatedRecord);
    return updatedRecord;
  }

  async deleteTerritoryRecord(id: number): Promise<boolean> {
    return this.territoryRecords.delete(id);
  }

  async getTerritoryRecordsByNumber(territoryNumber: number): Promise<TerritoryRecord[]> {
    return Array.from(this.territoryRecords.values())
      .filter(record => record.territoryNumber === territoryNumber)
      .sort((a, b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime());
  }

  async searchTerritoryRecordsByPerson(personName: string): Promise<TerritoryRecord[]> {
    const searchTerm = personName.toLowerCase();
    return Array.from(this.territoryRecords.values())
      .filter(record => record.personInCharge.toLowerCase().includes(searchTerm))
      .sort((a, b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime());
  }

  // Methods for backup/restore functionality
  exportData(): { territoryRecords: TerritoryRecord[] } {
    return {
      territoryRecords: Array.from(this.territoryRecords.values())
    };
  }

  importData(data: { territoryRecords: TerritoryRecord[] }): void {
    this.territoryRecords.clear();
    let maxId = 0;
    
    data.territoryRecords.forEach(record => {
      this.territoryRecords.set(record.id, record);
      if (record.id > maxId) {
        maxId = record.id;
      }
    });
    
    this.currentRecordId = maxId + 1;
  }
}

export const storage = new DatabaseStorage();
