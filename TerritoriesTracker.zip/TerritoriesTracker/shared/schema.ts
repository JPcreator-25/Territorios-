import { pgTable, text, serial, integer, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const territoryRecords = pgTable("territory_records", {
  id: serial("id").primaryKey(),
  territoryNumber: integer("territory_number").notNull(),
  personInCharge: text("person_in_charge").notNull(),
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  notes: text("notes"),
});

export const insertTerritoryRecordSchema = createInsertSchema(territoryRecords).omit({
  id: true,
}).extend({
  territoryNumber: z.number().min(1).max(34),
  personInCharge: z.string().min(1, "El encargado es requerido"),
  startDate: z.string().min(1, "La fecha de inicio es requerida"),
  endDate: z.string().min(1, "La fecha final es requerida"),
  notes: z.string().optional(),
});

export type InsertTerritoryRecord = z.infer<typeof insertTerritoryRecordSchema>;
export type TerritoryRecord = typeof territoryRecords.$inferSelect;

// Keep existing users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
