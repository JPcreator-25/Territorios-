import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { insertTerritoryRecordSchema, type InsertTerritoryRecord, type TerritoryRecord } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Save, RefreshCw } from "lucide-react";

interface TerritoryFormProps {
  onImportClick: () => void;
}

export default function TerritoryForm({ onImportClick }: TerritoryFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<InsertTerritoryRecord>({
    resolver: zodResolver(insertTerritoryRecordSchema),
    defaultValues: {
      territoryNumber: 0,
      personInCharge: "",
      startDate: "",
      endDate: "",
      notes: "",
    },
  });

  // Fetch recent records
  const { data: recentRecords = [] } = useQuery<TerritoryRecord[]>({
    queryKey: ["/api/territory-records"],
  });

  const createRecordMutation = useMutation({
    mutationFn: async (data: InsertTerritoryRecord) => {
      const response = await apiRequest("POST", "/api/territory-records", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Registro guardado",
        description: "El registro del territorio se ha guardado exitosamente.",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/territory-records"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo guardar el registro.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertTerritoryRecord) => {
    createRecordMutation.mutate(data);
  };

  const onClear = () => {
    form.reset();
  };

  const recentRecordsToShow = recentRecords.slice(0, 3);

  return (
    <div className="space-y-6">
      {/* Form Card */}
      <Card>
        <CardHeader className="bg-slate-50 border-b border-slate-200">
          <CardTitle className="text-lg font-semibold text-slate-800">
            Registrar Trabajo de Territorio
          </CardTitle>
          <CardDescription className="text-sm text-slate-600">
            Complete la información del trabajo realizado en el territorio
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Territory Number */}
                <FormField
                  control={form.control}
                  name="territoryNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-slate-700">
                        Número de Territorio <span className="text-red-500">*</span>
                      </FormLabel>
                      <Select 
                        onValueChange={(value) => field.onChange(parseInt(value))}
                        value={field.value ? field.value.toString() : ""}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccionar territorio..." />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {Array.from({ length: 34 }, (_, i) => i + 1).map((num) => (
                            <SelectItem key={num} value={num.toString()}>
                              Territorio {num}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Person in Charge */}
                <FormField
                  control={form.control}
                  name="personInCharge"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-slate-700">
                        Encargado <span className="text-red-500">*</span>
                      </FormLabel>
                      <FormControl>
                        <Input placeholder="Nombre del encargado" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Start Date */}
                <FormField
                  control={form.control}
                  name="startDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-slate-700">
                        Fecha de Inicio <span className="text-red-500">*</span>
                      </FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* End Date */}
                <FormField
                  control={form.control}
                  name="endDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-slate-700">
                        Fecha Final <span className="text-red-500">*</span>
                      </FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Notes */}
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-medium text-slate-700">
                      Observaciones y Notas
                    </FormLabel>
                    <FormControl>
                      <Textarea 
                        rows={4}
                        placeholder="Notas adicionales sobre el trabajo realizado..."
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Form Actions */}
              <div className="flex justify-end space-x-3 pt-4 border-t border-slate-200">
                <Button
                  type="button"
                  variant="ghost"
                  onClick={onClear}
                  className="text-slate-600 hover:text-slate-800"
                >
                  Limpiar
                </Button>
                <Button
                  type="submit"
                  disabled={createRecordMutation.isPending}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {createRecordMutation.isPending ? (
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  ) : (
                    <Save className="mr-2 h-4 w-4" />
                  )}
                  Guardar Registro
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>

      {/* Recent Records Preview */}
      <Card>
        <CardHeader className="bg-slate-50 border-b border-slate-200">
          <CardTitle className="text-lg font-semibold text-slate-800">
            Registros Recientes
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          {recentRecordsToShow.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-slate-500">No hay registros recientes</p>
              <Button
                variant="outline"
                onClick={onImportClick}
                className="mt-4"
              >
                <i className="fas fa-upload mr-2"></i>
                Importar Datos
              </Button>
            </div>
          ) : (
            <div className="space-y-0">
              {recentRecordsToShow.map((record) => {
                const duration = Math.ceil(
                  (new Date(record.endDate).getTime() - new Date(record.startDate).getTime()) / (1000 * 60 * 60 * 24)
                );
                
                return (
                  <div 
                    key={record.id}
                    className="flex items-center justify-between py-3 border-b border-slate-100 last:border-b-0"
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center font-semibold">
                        {record.territoryNumber}
                      </div>
                      <div>
                        <p className="font-medium text-slate-800">{record.personInCharge}</p>
                        <p className="text-sm text-slate-600">
                          {new Date(record.startDate).toLocaleDateString('es-ES')} - {new Date(record.endDate).toLocaleDateString('es-ES')}
                        </p>
                      </div>
                    </div>
                    <span className="text-xs font-medium text-emerald-600 bg-emerald-50 px-2 py-1 rounded-full">
                      Completado
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
