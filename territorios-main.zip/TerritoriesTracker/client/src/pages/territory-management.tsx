import { useState } from "react";
import { MapPin } from "lucide-react";
import TerritoryForm from "@/components/territory-form";
import TerritoryHistory from "@/components/territory-history";
import TerritoryQuery from "@/components/territory-query";
import ExportModal from "@/components/export-modal";
import ImportModal from "@/components/import-modal";
import { Button } from "@/components/ui/button";

export default function TerritoryManagement() {
  const [activeView, setActiveView] = useState<'form' | 'history' | 'query'>('form');
  const [showExportModal, setShowExportModal] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <MapPin className="text-blue-600 h-6 w-6 mr-3" />
              <h1 className="text-xl font-semibold text-slate-800">Gestión de Territorios</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Button
                variant={activeView === 'form' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setActiveView('form')}
                className={activeView === 'form' 
                  ? 'bg-blue-50 text-blue-600 hover:bg-blue-100' 
                  : 'text-slate-600 hover:text-slate-800 hover:bg-slate-100'
                }
              >
                <i className="fas fa-plus mr-2"></i>Nuevo Registro
              </Button>
              <Button
                variant={activeView === 'history' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setActiveView('history')}
                className={activeView === 'history' 
                  ? 'bg-blue-50 text-blue-600 hover:bg-blue-100' 
                  : 'text-slate-600 hover:text-slate-800 hover:bg-slate-100'
                }
              >
                <i className="fas fa-history mr-2"></i>Historial
              </Button>
              <Button
                variant={activeView === 'query' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setActiveView('query')}
                className={activeView === 'query' 
                  ? 'bg-blue-50 text-blue-600 hover:bg-blue-100' 
                  : 'text-slate-600 hover:text-slate-800 hover:bg-slate-100'
                }
              >
                <i className="fas fa-search mr-2"></i>Consultas
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowExportModal(true)}
                className="text-slate-600 hover:text-slate-800 hover:bg-slate-100"
              >
                <i className="fas fa-download mr-2"></i>Exportar
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeView === 'form' ? (
          <TerritoryForm onImportClick={() => setShowImportModal(true)} />
        ) : activeView === 'history' ? (
          <TerritoryHistory />
        ) : (
          <TerritoryQuery />
        )}
      </main>

      {/* Modals */}
      <ExportModal 
        open={showExportModal} 
        onOpenChange={setShowExportModal} 
      />
      <ImportModal 
        open={showImportModal} 
        onOpenChange={setShowImportModal} 
      />
    </div>
  );
}
