# Territory Management System

## Overview

This is a full-stack web application for managing territory assignments and records. The system allows users to create, track, and manage territory assignments with detailed records including person in charge, dates, and notes. It features a modern React frontend with a Node.js/Express backend, using PostgreSQL for data persistence.

## System Architecture

**Frontend Architecture:**
- React 18 with TypeScript
- Vite for build tooling and development server
- Wouter for lightweight client-side routing
- TanStack React Query for server state management
- Shadcn/ui component library with Radix UI primitives
- Tailwind CSS for styling
- React Hook Form with Zod validation

**Backend Architecture:**
- Node.js with Express.js framework
- TypeScript for type safety
- Drizzle ORM for database operations
- Neon Database (PostgreSQL) for data storage
- RESTful API design

**Database Schema:**
- PostgreSQL database with two main tables:
  - `territory_records`: Core entity storing territory assignments
  - `users`: User authentication (basic structure present)

## Key Components

**Database Layer:**
- Drizzle ORM with PostgreSQL dialect
- Schema defined in `shared/schema.ts` for type safety across frontend/backend
- Territory records with fields: id, territoryNumber (1-34), personInCharge, startDate, endDate, notes

**API Layer:**
- RESTful endpoints for territory records CRUD operations
- Input validation using Zod schemas
- Error handling middleware
- Development logging for API requests

**Frontend Components:**
- `TerritoryForm`: Form for creating new territory records
- `TerritoryHistory`: Table view with search and filtering capabilities
- `ExportModal`: Data export functionality (JSON format)
- `ImportModal`: Data import with drag-and-drop interface
- Comprehensive UI component library from Shadcn/ui

**Storage Architecture:**
- `IStorage` interface in `server/storage.ts`
- `DatabaseStorage` implementation using PostgreSQL with Drizzle ORM
- `MemStorage` implementation available for testing
- Database connection via Neon Database with connection pooling

## Data Flow

1. **User Input**: Forms capture territory assignment data with client-side validation
2. **API Communication**: React Query manages server state and API calls
3. **Server Processing**: Express routes handle requests with validation and business logic
4. **Data Persistence**: Drizzle ORM handles database operations
5. **Real-time Updates**: React Query automatically updates UI when data changes

## External Dependencies

**Database:**
- Neon Database (PostgreSQL) - configured via `DATABASE_URL` environment variable
- Connection pooling with `@neondatabase/serverless`

**UI Framework:**
- Radix UI primitives for accessible components
- Lucide React for icons
- TailwindCSS for styling

**Development Tools:**
- Replit-specific plugins for development environment
- Vite plugins for hot reload and error overlay

## Deployment Strategy

**Development:**
- Vite dev server serves frontend on port 5000
- Express server handles API routes and serves static files in production
- Concurrent development with middleware integration

**Production Build:**
- Frontend builds to `dist/public` directory
- Backend bundles with esbuild to `dist/index.js`
- Single deployment target serving both frontend and API

**Environment Configuration:**
- Replit deployment with autoscale target
- Environment variables for database connection
- Port configuration for external access

**Database Migrations:**
- Drizzle Kit for schema management
- `npm run db:push` for development schema updates
- Migration files stored in `./migrations` directory

## Changelog

```
Changelog:
- June 25, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```